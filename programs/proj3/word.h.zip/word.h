#ifndef _WORD_H
#define _WORD_H
#include "file.h"
#include <string>
#include <cstring>
using namespace std;

class Word{
  string word;
  int count;
  File* files;
  int size;
  // DO NOT REMOVE THE ABOVE MEMBER VARIABLES

  // ADD NEW MEMBER VARIABLES HERE IF NEEDED
public:
  Word() {word = ""; count = -1;}  // default constructor to keep compiler happy; DO NOT DELETE
  Word(std::string name); // constructor
  string getWord() const;
  int getCount() const;
  void setCount();
  int getSize();
  void addFile(string filename);
  File getFile(int index);

  // ADD NEW MEMBER FUNCTIONS HERE AS NEEDED

};
#endif
